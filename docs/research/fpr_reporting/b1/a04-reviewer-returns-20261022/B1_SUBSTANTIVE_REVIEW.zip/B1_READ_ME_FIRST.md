# Warrant Stage B1 — substantive restricted-evidence scientific screening

Review generated (UTC): 2026-10-22T11:10:53+00:00

## Counts

- Frozen work IDs reconciled: **372**; frozen memberships: **389**.
- Restricted method facts individually indexed/reviewed: **828** (549 semantic, 278 recovery, one base).
- **INCLUDE 6**, **EXCLUDE 8**, **UNCLEAR 358**; statuses and reasons are in `B1_ELIGIBILITY_REVIEW_372.json` and `B1_SCIENTIFIC_WORK_RATIONALES.json`.
- Positive, evidence-linked criterion judgments: {"input_injection_task": 73, "binary_evaluation": 67, "before_target_answer": 36, "english_evaluation": 12}.
- Reviewer-generated narrow follow-up requests: **1302**, excluding already-supported criteria where possible.

## Domain adjudication

The six strongest four-criterion candidates identified for independent checking are W0011, W0020, W0062, W0095, W0200, W0327. Each has a specific recorded qualifying binary prompt-injection input evaluation with chronology and an English evaluation component. Version decisions are checked against the official revision histories and binding records; see individual reports. An `INCLUDE` is the best evidence-limited scientific judgment, **not a signed A04 fresh-reviewer approval**.

Surveys, proposal-only work and exact sentinel exclusions are distinguished from missing evidence. Nonqualifying studied components (e.g., output judges, benign/harmful labels, tool-action allow/deny, post-answer inspection) are described without inferring that uninspected baseline experiments were absent.

## Protocol/independence and gate

The original `REVIEWER_RECOVERY_TRANSFER.zip` bytes were **not uploaded**. The three original component verifiers and a recovery *extracted-files consistency test* previously passed. The outer ZIP hash **cannot** be compared to the supplied out-of-band SHA-256, and `verify_recovery.py` was not run against an authentic extracted wrapper. Do not claim the original transfer is authenticated.

This conversation contains prior assistant screening judgments. Its current work therefore **cannot** truthfully attest fresh A04 reviewer independence. The attached artifact is a real work-by-work evidence assessment that can be independently reviewed/reproduced in a separate authorized fresh reviewer context; it does not replace the required fresh attestation.

No new discovery; no source-repository access; no historical decision inspection; no outcome/statistic extraction; no sampling or B2. **B1 approval gate: FRAME_BLOCKED**.
