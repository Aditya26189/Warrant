# High-priority B1 eligibility adjudication notes

**Scope.** Only the supplied method/dataset and bibliographic excerpts were used. An original input-injection binary detector is distinguishable from a general harmfulness classifier, an attack-generator reward model, a target-response judge, or a tool-policy-action filter. Evidence supporting a specific experimental arm does not prove the absence of another, uninspected baseline arm.

## Six evidence-supported qualifying original experiments

- **W0011 / arxiv:2406.00799v6 — INCLUDE (restricted-evidence scientific screen).** `REC-REC-01-W0011-F01` distinguishes clean data blocks from injected-task blocks; `REC-REC-01-W0011-F02` locates the last input-token activation before response generation; `REC-REC-01-W0011-F03` documents English question-answering/summarization task and injected-trigger templates. `SEM-01-W0011-F01` grounds the third-party-data input task. The official revision history and exact-version self-link support the selected v6 within cutoff. The work also uses SQuAD/HotPotQA splits, but those *names alone* are not used to infer language.

- **W0020 / arxiv:2410.21146v1 — INCLUDE with revision-provenance caveat.** `REC-REC-01-W0020-F01` documents injection-presence labels and a binary BERT head; `-F02` screens before the distinct target model; `-F03` documents English prompt dataset and train/test division. Official arXiv history contains only v1, and the source URL is explicit v1. The body does not independently state its revision identifier; this limitation remains recorded and must be checked at final gate.

- **W0062 / arxiv:2507.15219v1 — INCLUDE.** `SEM-01-W0062-F01` documents PromptArmor checking injected content, `-F02` documents its operation before backend processing, `REC-REC-01-W0062-F01` distinguishes guard/backend roles, and `REC-REC-01-W0062-F02` identifies English injection inputs at AgentDojo evaluation points. Same foundation model used in different roles does not itself defeat temporal separation.

- **W0095 / arxiv:2510.14005v3 — INCLUDE.** `SEM-01-W0095-F01` uses clean/contaminated binary labels on prompt-state features; `REC-REC-01-W0095-F01` establishes final input-token detection before the next generation token; `REC-REC-01-W0095-F02` describes English injected instructions in long-context evaluation. v3 is the last cited official arXiv revision before cutoff and is self-linked in its body.

- **W0200 / arxiv:2605.07269v1 — INCLUDE.** `SEM-02-SC02-W0200-R0003-F01` identifies indirect-injection presence/absence text labels; `-F02` says detection occurs before the downstream victim consumes the text; `-F03` identifies English and Bangla benchmark samples. The rules require actual English evaluation, *not* an English-only split; no language percentages were inferred.

- **W0327 / arxiv:2610.08571v1 — INCLUDE.** `SEM-03-SC03-W0327-F01` describes attacker-controlled retrieved text, `-F02` pre-generation RAG-input detection, `-F03` benign versus prompt-injection labels and `-F04` an explicitly English-text benchmark. Official first-public and v1 dates precede the 2026-10-17 cutoff.

## Explicit work-level exclusions and persistent ambiguities

Five originals have exact matches to locked sentinel identifiers: **W0053, W0181, W0199, W0224, W0300**. Three additional exclusions rely on affirmative source-method evidence that the *work itself* is not an original empirical evaluation of the required binary input-injection detector: **W0127** (literature review using prior evaluations), **W0164** (taxonomy/evidence synthesis), and **W0369** (proposal, explicitly no pilot/data). No work was excluded solely for PDF access failure, missing evidence, or missing abstracts.

- **W0015** has a supported injection-versus-benign classifier and explicitly an English component in the tested mixed-language corpus, but source evidence does not independently document chronology relative to a distinct protected target; `UNCLEAR` remains.
- **W0058** uses a known-answer detector before a separate backend, but the English passage documents the *auxiliary detector instruction*, not necessarily the language of the evaluated incoming data; `UNCLEAR` remains on English input setting.
- **W0125** has paired injected/clean email-content classification and English LLMail-Inject filtering, but its embedding-drift fact does not itself establish the prediction's position relative to a distinct downstream target response; `UNCLEAR` timing.
- **W0208** has binary injection detection and English-only evaluations, but the pre-generation source fact refers to the *guard model's* verdict. It does not expressly settle timing relative to another protected target; `UNCLEAR` timing.
- **W0339** meets all four scientific criteria in arxiv:2609.15017v1 but has a linked journal DOI. DOI deposit/create/issued YEAR metadata do not prove public publisher-VOR availability by cutoff; `UNCLEAR` preferred version, no guessed substitution.
- **W0352** has method facts split between the original arXiv preprint and a subsequently published ACL version of record. Prefer the ACL version, but do not automatically treat all preprint-specific method excerpts as demonstrated in the publisher version; hold `UNCLEAR` pending controlled same-version confirmation.
- **W0048** captures a withdrawn latest preprint revision: do not substitute its accessible earlier revision for method adjudication. **W0136** has a later post-cutoff revision: do not silently transfer later-version method evidence to a prior pre-cutoff revision.

## Limitations

This is a substantive, evidence-limited work-by-work eligibility screening return. It does **not** authenticate the missing transport ZIP's stated SHA-256 or establish a fresh independent A04 reviewer attestation. Historical custodian decisions, outcomes, statistical findings, result tables and source repositories remain outside the review. The B1 approval gate remains `FRAME_BLOCKED`; no B2 work is authorized.
