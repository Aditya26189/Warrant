"""Offline mechanical verification of THIS evidence-limited B1 return only.
Does not authenticate absent outer transfer or certify independent review freshness.
Run: python -I B1_VERIFY_RETURN.py from this directory.
"""
from pathlib import Path
import json, hashlib, collections
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((P/n).read_text(encoding='utf-8'))
m=read('B1_SHA256_MANIFEST.json')
assert set(m['files'])=={p.name for p in P.iterdir() if p.is_file() and p.name!='B1_SHA256_MANIFEST.json'},'Manifest inventory not complete'
for name,digest in m['files'].items():
 assert sha(P/name)==digest, f'Hash mismatch: {name}'
review=read('B1_ELIGIBILITY_REVIEW_372.json'); rationales=read('B1_SCIENTIFIC_WORK_RATIONALES.json'); fact=read('B1_ALL_METHOD_FACT_ASSESSMENTS.json');req=read('B1_PRECISION_CONTROLLED_REQUESTS.json');v=read('B1_VALIDATION.json')
assert len(review)==len(rationales)==372
assert len(fact)==828
assert len({w['work_id'] for w in review})==372
assert len({w['review_id'] for w in review})==372
assert len({m for r in rationales for m in r['memberships']})==389
assert len({e['evidence_id'] for e in fact})==828
rid={r['review_id']:r for r in review}; eid={x['evidence_id'] for x in fact}
for x in rationales:
 assert rid[x['review_id']]['decision']==x['decision']
 assert all(z['evidence_id'] in eid for z in x['method_evidence_considered'])
 for c,t in x['criterion_review'].items():
  assert t['decision']==rid[x['review_id']][c]
  assert all(i in eid for i in t['restricted_primary_method_evidence_ids']+t['other_relevant_evidence_ids'])
  if t['decision']=='YES':assert t['restricted_primary_method_evidence_ids'],(x['review_id'],c)
for x in review:
 if x['decision']=='INCLUDE':
  assert x['selected_version_id']
  assert all(x[z]=='YES' for z in ('input_injection_task','binary_evaluation','before_target_answer','english_evaluation'))
 if x['decision']=='EXCLUDE':assert x['limitations'] or x['sentinel_check']=='DIRECT_LOCKED_SENTINEL_MATCH_EXCLUDED'
for x in req:assert x['review_id'] in rid and rid[x['review_id']]['decision']=='UNCLEAR' and x['criterion'] in ('version','input_injection_task','binary_evaluation','before_target_answer','english_evaluation')
assert collections.Counter(x['decision'] for x in review)==collections.Counter(v['decisions'])
assert len(req)==v['explicit_material_followup_requests']
assert v['A04_freshness_attested'] is False and v['gate']=='FRAME_BLOCKED'
assert v['outer_zip_authentication'].startswith('NOT_POSSIBLE')
print(json.dumps({'status':'PASS','works':len(review),'members':389,'method_facts':len(fact),'requests':len(req),'decisions':v['decisions'],'fresh_A04_attestation':False,'gate':v['gate']},sort_keys=True))
