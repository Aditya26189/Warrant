# Independent Warrant Stage B1 Eligibility Reviews

This archive contains the completed, independent eligibility reviews for all 372 candidate works (and 389 memberships) from the Warrant Stage B1 candidate inventory.

## Contents
- `ELIGIBILITY_REVIEW.json`: Consolidated JSON array of all 372 work review records in exact inventory order.
- `INDEX.json`: Summary index mapping each review ID (`W0001` - `W0372`) to its work ID, decision, selected version, and individual review file.
- `reviews/`: Directory containing all 372 individual review JSON files (`W0001.json` through `W0372.json`).

## Review Summary
- **Total Works Evaluated:** 372
- **ELIGIBLE:** 6 (`W0020`, `W0200`, `W0208`, `W0327`, `W0339`, `W0352`)
- **EXCLUDED:** 8 (5 sentinels `W0053`, `W0181`, `W0199`, `W0224`, `W0300`; 2 withdrawn `W0021`, `W0067`; 1 tool-policy only `W0290`)
- **UNCLEAR:** 358 (material evidence unresolved; precise controlled requests returned)
- **Reviewer ID:** `INDEPENDENT_REVIEWER`
- **Reviewed UTC:** `2026-10-22T11:15:00Z`
